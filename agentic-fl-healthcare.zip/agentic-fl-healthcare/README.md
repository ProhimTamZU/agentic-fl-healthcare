# Agentic Federated Learning (AFL) for Privacy-Preserving Healthcare Edge Networks

Reference implementation and simulation code for the paper

> **Prohim Tam and Seokhoon Kim.** *Agentic Federated Learning: An Intelligent Multi-Agent
> Orchestration Framework for Privacy-Preserving Healthcare Edge Networks.* 2026.

AFL places four cooperating agents (Monitor, Planner, Security, Executor) at each
healthcare edge site. The agents **observe** the network through Model Context Protocol (MCP)
*resources* (per-cell telemetry, client reputation), **plan** client selection and bandwidth
allocation with latency-optimal tools, **verify** model updates (norm/direction screening, a
root-set loss test and Beta reputation), and **act** through guarded MCP *tools* that wrap
southbound APIs (O-RAN A1 policy, SDN north-bound REST, FL server, Kubernetes).
An edge LLM runs only as a slow, event-triggered strategist and is pipelined with training.

## Repository layout

| Path | Content |
|---|---|
| `afl/data.py` | CTG (UCI Cardiotocography, 2,126 exams, 21 features, 3 classes) and WDBC loaders, Dirichlet non-IID split, edge root set |
| `afl/model.py` | NumPy MLP (21-64-3), SGD and DP-SGD with per-example clipping |
| `afl/network.py` | System model: computation, uplink/downlink (Shannon rate, 3GPP path loss, shadowing, Rayleigh), M/M/1 edge queue, aggregation, screening, backhaul (Eqs. 1-5) |
| `afl/mcp.py` | Minimal MCP layer: JSON-RPC 2.0 `initialize`, `tools/list`, `tools/call`, `resources/read`; HS256 bearer tokens with OAuth scopes; JSON-Schema validation; Streamable-HTTP latency model (Eq. 6) |
| `afl/agents.py` | Southbound APIs exposed as MCP tools, the four agents, the 3-layer policy guard, the LLM latency profile and the tool-call injection catalogue |
| `afl/optim.py` | Trust-weighted selection (Eq. 12) and min-max bandwidth allocation by nested bisection (Eq. 13) |
| `afl/security.py` | Attacks (sign-flip, Gaussian, scaling, label-flip), screening (Eqs. 14-16), weighted trimmed mean, RDP accountant for the sampled Gaussian mechanism, measured AES-GCM/HMAC cost |
| `afl/fl.py` | Round engine for FedAvg, FedAvg-TM, FedCS, AFL-Seq, AFL-NoGuard and AFL; exposed control time and per-round latency (Eqs. 7-10) |
| `experiments/run_all.py` | All experiments (5 seeds, 261 runs, ~5 min on 2 cores) |
| `experiments/make_figures.py` | Figures (paper Fig. 2 = `figures/fig2_results_4panel.png`) and `results/summary.json` |
| `experiments/draw_architecture.py` | Fig. 1 |
| `tests/` | Unit tests (`python -m pytest -q`) |

## Quick start

```bash
pip install -r requirements.txt
python -m pytest -q tests
python experiments/run_all.py --seeds 5 --rounds 100   # writes results/all_results.json
python experiments/make_figures.py                     # writes figures/*.png, results/summary.json
```

Single run:

```python
from afl import run, RunConfig
out = run(RunConfig(scheme="AFL", attack="signflip", byz_frac=0.2, rounds=100, seed=0))
print(out["log"][-1]["acc"], out["detection"], out["mcp"])
```

## Main results (CTG, N = 20, 20 % Byzantine clients, mean of 5 seeds)

| Scheme | Mean round latency (s), no attack | Time to 85 % acc. (s), no attack | Macro-F1, sign-flip | Macro-F1, label-flip |
|---|---|---|---|---|
| FedAvg | 27.90 | 303 | 0.242 | 0.598 |
| FedAvg-TM | 27.92 | 271 | 0.448 | 0.719 |
| FedCS | 9.20 | 70 | 0.300 | 0.673 |
| AFL-Seq | 12.01 | 107 | 0.769 | 0.739 |
| **AFL** | **5.57** | **58** | **0.764** | **0.741** |

With 20 % of planner turns carrying injected tool calls, the policy guard blocked all 98 attempts
(L1 allow-list 30, L2 schema 11, L3 invariants 57); without it 60 of 107 were executed.
Mean MCP call latency was 11.8 ms (602 B, 19 µs token verification).

## Notes and limitations

* Accuracy is measured on the real CTG benchmark; latency uses a deployment profile
  (S = 8 Mbit payload, 2x10^7 cycles/sample) so that network effects match an ECG/CTG CNN.
* The LLM strategist's *latency* is modelled from prompt token counts (1,200 tok/s prefill,
  30 tok/s decode); its *decisions* are emulated by a deterministic rule set.
* Southbound APIs are emulated with measured-range latencies; the MCP messages are real JSON-RPC.
* Data: UCI Cardiotocography (CC BY 4.0), cached in `data/CTG.csv`.

## License

MIT
