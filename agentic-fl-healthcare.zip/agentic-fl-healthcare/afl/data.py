"""Healthcare benchmark loading and non-IID federated partitioning.

Benchmarks
----------
* CTG  - UCI Cardiotocography (Ayres-de-Campos et al., 2000): 2,126 fetal CTG
         exams, 21 clinical features, 3 classes (NSP: normal / suspect /
         pathologic). Used as the primary IoMT edge-diagnosis task.
* WDBC - Wisconsin Diagnostic Breast Cancer (bundled with scikit-learn):
         569 samples, 30 features, 2 classes. Used as a secondary task.
"""
from __future__ import annotations

import os
import numpy as np

CTG_FEATURES = ["LB", "AC", "FM", "UC", "ASTV", "MSTV", "ALTV", "MLTV", "DL",
                "DS", "DP", "Width", "Min", "Max", "Nmax", "Nzeros", "Mode",
                "Mean", "Median", "Variance", "Tendency"]
CTG_URL = ("https://raw.githubusercontent.com/pycaret/datasets/main/"
           "data/common/CTG.csv")
_HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.dirname(_HERE), "data")


def _standardize(xtr, xte):
    mu, sd = xtr.mean(0), xtr.std(0) + 1e-8
    return (xtr - mu) / sd, (xte - mu) / sd


def load_ctg(path: str | None = None):
    """Return (X, y) for the CTG benchmark; y in {0,1,2}."""
    import csv
    path = path or os.path.join(DATA_DIR, "CTG.csv")
    if not os.path.exists(path):  # pragma: no cover - network fallback
        import urllib.request
        os.makedirs(os.path.dirname(path), exist_ok=True)
        urllib.request.urlretrieve(CTG_URL, path)
    X, y = [], []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            if not row.get("NSP"):
                continue
            try:
                X.append([float(row[f]) for f in CTG_FEATURES])
                y.append(int(float(row["NSP"])) - 1)
            except (ValueError, TypeError):
                continue
    return np.asarray(X, dtype=np.float64), np.asarray(y, dtype=np.int64)


def load_wdbc():
    from sklearn.datasets import load_breast_cancer
    d = load_breast_cancer()
    return d.data.astype(np.float64), d.target.astype(np.int64)


def train_test_split(X, y, test_frac=0.2, seed=0):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    n_te = int(round(test_frac * len(y)))
    te, tr = idx[:n_te], idx[n_te:]
    xtr, xte = _standardize(X[tr], X[te])
    return xtr, y[tr], xte, y[te]


def dirichlet_partition(y, n_clients, alpha=0.5, seed=0, min_size=8):
    """Label-skewed non-IID split (Hsu et al., 2019)."""
    rng = np.random.default_rng(seed)
    classes = np.unique(y)
    while True:
        parts = [[] for _ in range(n_clients)]
        for c in classes:
            idx = rng.permutation(np.where(y == c)[0])
            p = rng.dirichlet(alpha * np.ones(n_clients))
            cuts = (np.cumsum(p) * len(idx)).astype(int)[:-1]
            for k, chunk in enumerate(np.split(idx, cuts)):
                parts[k].extend(chunk.tolist())
        if min(len(p) for p in parts) >= min_size:
            return [np.asarray(p) for p in parts]


def load_benchmark(name="ctg", n_clients=20, alpha=0.5, seed=0, root_size=0):
    """Return (clients, test, n_classes[, root]). If root_size > 0, a small
    curated validation set held by the edge security agent is carved out of
    the training pool before partitioning (FLTrust-style root data)."""
    X, y = load_ctg() if name == "ctg" else load_wdbc()
    xtr, ytr, xte, yte = train_test_split(X, y, seed=seed)
    root = None
    if root_size > 0:
        r = np.random.default_rng(seed + 5).permutation(len(ytr))
        root = (xtr[r[:root_size]], ytr[r[:root_size]])
        xtr, ytr = xtr[r[root_size:]], ytr[r[root_size:]]
    parts = dirichlet_partition(ytr, n_clients, alpha, seed,
                                min_size=max(2, min(8, len(ytr) // (6 * n_clients))))
    clients = [(xtr[p], ytr[p]) for p in parts]
    if root_size > 0:
        return clients, (xte, yte), int(y.max() + 1), root
    return clients, (xte, yte), int(y.max() + 1)
