"""Federated-learning round engine for the agentic scheme and baselines.

Per-round latency (Eqs. 9-10 of the paper):
  T_r = T_ctl + T_dn + max_{i in A_r}(T_i^cmp + T_i^up + T_i^enc) + T_q + T_sec + T_agg + T_bh
where the exposed control overhead T_ctl depends on the scheme (Eq. 8).
"""
from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np

from .data import load_benchmark
from .model import MLP
from .network import EdgeNetwork, NetConfig
from . import optim, security
from .agents import AgentSystem, LLMProfile

SCHEMES = ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL-NoGuard", "AFL"]


@dataclass
class RunConfig:
    scheme: str = "AFL"
    dataset: str = "ctg"
    n_clients: int = 20
    rounds: int = 100
    m: int = 8
    epochs: int = 2
    lr: float = 0.05
    hidden: int = 64
    alpha: float = 0.5
    byz_frac: float = 0.2
    attack: str = "signflip"         # signflip | gaussian | scaling | labelflip | none
    p_inject: float = 0.0
    dp_sigma: float = 0.0            # DP-SGD noise multiplier (0 disables)
    dp_clip: float = 1.0
    dp_budget: float = 8.0           # per-client epsilon budget enforced by the agent
    dp_batch: int = 64
    dp_lr: float = 0.3
    fedcs_deadline: float = 12.0
    root_size: int = 60              # curated edge validation samples (AFL only)
    seed: int = 0


def run(cfg: RunConfig, net_cfg: NetConfig | None = None, crypto=None):
    rng = np.random.default_rng(cfg.seed + 1000)
    agentic = cfg.scheme.startswith("AFL")
    # identical client partitions for every scheme; only AFL uses the root set
    clients, (xte, yte), n_cls, root = load_benchmark(cfg.dataset, cfg.n_clients, cfg.alpha,
                                                      cfg.seed, root_size=cfg.root_size)
    D = [len(c[1]) for c in clients]
    net_cfg = net_cfg or NetConfig(n_clients=cfg.n_clients, seed=cfg.seed)
    net = EdgeNetwork(net_cfg)
    model = MLP(xte.shape[1], cfg.hidden, n_cls, seed=cfg.seed)
    theta = model.theta.copy()
    n_mal = int(round(cfg.byz_frac * cfg.n_clients)) if cfg.attack != "none" else 0
    malicious = set(np.random.default_rng(cfg.seed + 77).choice(cfg.n_clients, n_mal, replace=False).tolist())
    crypto = crypto or {"aes_gcm_enc_s": 0.0, "aes_gcm_dec_s": 0.0, "hmac_sha256_s": 0.0}
    t_enc = crypto["aes_gcm_enc_s"] + crypto["hmac_sha256_s"]
    t_dec = crypto["aes_gcm_dec_s"] + crypto["hmac_sha256_s"]

    agents = None
    if agentic:
        agents = AgentSystem(net, cfg.n_clients, rng, use_guard=cfg.scheme != "AFL-NoGuard",
                             llm_every=10, pipelined=cfg.scheme != "AFL-Seq",
                             p_inject=cfg.p_inject, llm=LLMProfile())
        agents.strategy["m"] = cfg.m
    dp_steps = np.zeros(cfg.n_clients)              # privacy ledger (steps at rate q_i)
    dp_q = np.array([min(1.0, cfg.dp_batch / d) for d in D])

    def eps_of(i, extra=0):
        return security.epsilon(dp_q[i], cfg.dp_sigma, int(dp_steps[i] + extra)) if dp_steps[i] + extra > 0 else 0.0

    log, acc_hist, wall = [], [], 0.0
    det = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for rnd in range(cfg.rounds):
        net.step()
        epochs = cfg.epochs
        T = {"obs": 0.0, "llm": 0.0, "opt": 0.0, "act": 0.0}
        # ---------------- control: selection + bandwidth -----------------
        if agentic and cfg.dp_sigma > 0:
            for i in range(cfg.n_clients):
                nxt = epochs * int(np.ceil(D[i] / cfg.dp_batch))
                if eps_of(i, nxt) > cfg.dp_budget:
                    agents.budget_exhausted.add(i)
        if agentic:
            tele, T["obs"] = agents.observe()
            chosen, shares, deadline, T["llm"], T["opt"], _ = agents.plan(rnd, tele, D, epochs, acc_hist)
            T["act"] = agents.act(rnd, chosen, shares, deadline, epochs)
            part = [i for i in agents.cp.selected if i not in agents.cp.quarantined
                    and agents.cp.flows.get(i) != "isolate"]
            epochs = agents.cp.epochs
            shares = agents.cp.shares.copy()
            for k in range(net_cfg.n_edges):       # RIC enforces sum(PRB share) <= 1
                idx = [i for i in part if net.edge_of[i] == k]
                tot = shares[idx].sum() if idx else 0
                if tot > 1:
                    shares[idx] /= tot
        else:
            avail = [i for i in range(cfg.n_clients) if net.available[i]]
            if cfg.scheme == "FedCS":
                # Nishio & Yonetani: greedy add clients that meet a fixed deadline
                cand = rng.permutation(avail)
                part = []
                for i in cand:
                    if len(part) >= cfg.m:
                        break
                    t_i = net.t_cmp(i, D[i], epochs) + net.t_up(i, 1.0 / cfg.m * net_cfg.n_edges)
                    if t_i <= cfg.fedcs_deadline:
                        part.append(int(i))
                deadline = cfg.fedcs_deadline
            else:
                part = [int(i) for i in rng.choice(avail, min(cfg.m, len(avail)), replace=False)]
                deadline = np.inf
            shares = np.zeros(cfg.n_clients)
            for k in range(net_cfg.n_edges):
                idx = [i for i in part if net.edge_of[i] == k]
                if idx:
                    shares[idx] = 1.0 / len(idx)
        part = sorted(set(int(i) for i in part))
        if not part:                       # all privacy budgets exhausted -> stop training
            break
        # planning-side control time (Eq. 7)
        t_ctrl = T["obs"] + T["llm"] + T["opt"]
        # ---------------- local training + upload --------------------------
        t_dn = net.t_down(np.array(part))
        deltas, finish, ids = [], [], []
        jitter = rng.uniform(0.9, 1.1, cfg.n_clients)       # CPU contention during the round
        for i in part:
            X, y = clients[i]
            if i in malicious and cfg.attack == "labelflip":
                y = security.flip_labels(y, n_cls)
            if cfg.dp_sigma > 0:
                th, st, _ = model.local_train_dp(theta, X, y, epochs, cfg.dp_lr, cfg.dp_clip, cfg.dp_sigma,
                                                 batch=cfg.dp_batch, rng=rng)
                dp_steps[i] += st
            else:
                th = model.local_train(theta, X, y, epochs, cfg.lr, rng=rng)
            d = th - theta
            if i in malicious and cfg.attack in ("signflip", "gaussian", "scaling"):
                d = security.poison_update(d, cfg.attack, rng)
            t_i = net.t_cmp(i, D[i], epochs) * jitter[i] + net.t_up(i, max(shares[i], 1e-6)) + t_enc
            finish.append(t_i)
            deltas.append(d)
            ids.append(i)
        finish = np.array(finish)
        if agentic or cfg.scheme == "FedCS":
            keep = finish <= deadline
            if not keep.any():
                keep = finish <= finish.min() + 1e-9
            t_train = min(float(finish.max()), float(deadline))
        else:
            keep = np.ones(len(ids), bool)
            t_train = float(finish.max())
        ids = [ids[j] for j in range(len(ids)) if keep[j]]
        deltas = [deltas[j] for j in range(len(deltas)) if keep[j]]
        n_upd = len(ids)
        if agentic:
            agents.drop_hist.append(1.0 - n_upd / len(part))
            agents.age += 1
            agents.age[ids] = 0
        # ---------------- security screening + aggregation -----------------
        t_sec = 0.0
        if agentic and cfg.scheme != "AFL-NoScreen":
            steps = [epochs * int(np.ceil(D[i] / 16)) for i in ids]
            gflags, gscore, mnorm = security.screen_updates(deltas, steps, agents.sec.get("mom"),
                                                            agents.strategy["tau"])
            vflags, dl = security.validation_screen(model, theta, deltas, root)
            # corroborated evidence (both detectors) or one extreme score
            evid = (gflags & vflags) | (gscore < 2 * agents.strategy["tau"])
            flags = evid.copy()
            t_sec = net.t_sec(n_upd, net_cfg.model_bits / 32)
            rep = agents.sec["rep"]
            for j, i in enumerate(ids):
                # Beta-reputation: rep_i = (pass_i + 1) / (pass_i + flag_i + 2)
                agents.sec["flag"][i] += int(evid[j])
                agents.sec["pass"][i] += int(not evid[j])
                rep[i] = (agents.sec["pass"][i] + 1) / (agents.sec["pass"][i] + agents.sec["flag"][i] + 2)
                mal = i in malicious
                det["tp"] += int(flags[j] and mal); det["fp"] += int(flags[j] and not mal)
                det["fn"] += int((not flags[j]) and mal); det["tn"] += int((not flags[j]) and not mal)
            acc = [j for j in range(n_upd) if not flags[j]] or list(range(n_upd))
            w = np.array([D[ids[j]] * rep[ids[j]] for j in acc])
            upd = [security.clip(deltas[j], 2.0 * mnorm) for j in acc]
            agg = security.weighted_trimmed_mean(np.stack(upd), w, 0.1)
            mom = agents.sec.get("mom")
            agents.sec["mom"] = agg.copy() if mom is None else 0.5 * mom + 0.5 * agg
            t_q_extra = 0.0
            for i in ids:
                n_obs = agents.sec["pass"][i] + agents.sec["flag"][i]
                if rep[i] < agents.rep_q and n_obs >= 4 and i not in agents.cp.quarantined:
                    _, lat = agents.quarantine(rnd, i)
                    t_q_extra += lat
                    agents.events += 1            # event-triggered LLM re-planning
            t_ctrl_post = t_q_extra
        elif cfg.scheme == "FedAvg-TM":
            agg = security.trimmed_mean(deltas, 0.2)
            t_sec = net.t_sec(n_upd, net_cfg.model_bits / 32) * 0.5
            t_ctrl_post = 0.0
        else:
            w = np.array([D[i] for i in ids], float)
            agg = np.average(np.stack(deltas), axis=0, weights=w / w.sum())
            t_ctrl_post = 0.0
        theta = theta + agg
        # ---------------- latency accounting --------------------------------
        k_agg = agents.cp.aggregator_edge if agentic else 0
        t_q = net.t_queue(k_agg)
        t_agg = net.t_agg(n_upd, net_cfg.model_bits / 32)
        t_bh = net.t_backhaul()
        t_cry = n_upd * t_dec / 4.0         # 4 decryption workers at the edge
        if agentic and cfg.scheme != "AFL-Seq":
            exposed = max(0.0, t_ctrl - t_train) + T["act"]   # planning overlapped with training
        else:
            exposed = t_ctrl + T["act"]
        T_r = exposed + t_dn + t_train + t_q + t_sec + t_agg + t_bh + t_cry + t_ctrl_post
        wall += T_r
        a = model.accuracy(theta, xte, yte)
        f1 = model.macro_f1(theta, xte, yte)
        acc_hist.append(a)
        mal_in = sum(1 for i in ids if i in malicious)
        log.append({"round": rnd, "acc": a, "f1": f1, "T_r": T_r, "wall": wall,
                    "t_ctrl_exposed": exposed + t_ctrl_post, "t_ctrl_total": t_ctrl + T["act"] + t_ctrl_post,
                    "t_llm": T["llm"], "t_obs": T["obs"], "t_opt": T["opt"], "t_act": T["act"],
                    "t_dn": t_dn, "t_train": t_train, "t_q": t_q, "t_sec": t_sec,
                    "t_agg": t_agg, "t_bh": t_bh, "t_crypto": t_cry,
                    "n_sel": len(part), "n_upd": n_upd, "n_mal_in": mal_in,
                    "dropped": int(len(part) - n_upd)})
    out = {"config": asdict(cfg), "log": log, "detection": det,
           "malicious": sorted(malicious)}
    if agentic:
        out["quarantined"] = sorted(agents.cp.quarantined)
        out["inject_log"] = agents.inject_log
        out["guard"] = dict(agents.guard.stats) if agents.guard else None
        out["guard_check_s"] = float(np.mean(agents.guard.t_check)) if agents.guard else 0.0
        out["exported_records"] = agents.cp.exported_records
        calls = [x for c in agents.edge_clients + [agents.fl_client] for x in c.log]
        out["mcp"] = {"calls": len(calls),
                      "mean_latency_s": float(np.mean([c["latency"] for c in calls])),
                      "mean_bytes": float(np.mean([c["bytes"] for c in calls])),
                      "mean_auth_s": float(np.mean([c["t_auth"] for c in calls]))}
    if cfg.dp_sigma > 0:
        eps = [eps_of(i) for i in range(cfg.n_clients)]
        out["dp"] = {"sigma": cfg.dp_sigma, "clip": cfg.dp_clip, "delta": 1e-5,
                     "eps_max": float(max(eps)), "eps_mean": float(np.mean(eps)),
                     "budget": cfg.dp_budget}
    return out
