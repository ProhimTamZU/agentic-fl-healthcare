"""Minimal Model Context Protocol (MCP) layer for edge agents.

Implements the JSON-RPC 2.0 message flow of the MCP specification (rev.
2025-06-18): ``initialize``, ``tools/list``, ``tools/call``, ``resources/list``,
``resources/read`` and ``notifications/resources/updated``. Messages are really
serialized to JSON so that payload sizes are exact; the Streamable-HTTP (Eq. 6)
transport is emulated with an analytical latency model

    t_call = RTT + 8 * (|req| + |resp|) / R_lan + t_auth + t_handler + t_api

where t_auth (bearer-token HMAC verification) and t_handler are measured wall-
clock times and t_api is the latency of the southbound network API wrapped by
the tool (O-RAN A1, SDN north-bound REST, FL server, Kubernetes).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import itertools
import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

PROTOCOL_VERSION = "2025-06-18"
_ids = itertools.count(1)


class MCPError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code, self.message = code, message


# ------------------------------------------------------------------ auth ---
def issue_token(secret: bytes, sub: str, scopes: list[str]) -> str:
    """Compact HS256 bearer token (JWT-style) carrying OAuth scopes."""
    hdr = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').rstrip(b"=")
    body = base64.urlsafe_b64encode(json.dumps(
        {"sub": sub, "scope": " ".join(scopes)}).encode()).rstrip(b"=")
    sig = base64.urlsafe_b64encode(hmac.new(secret, hdr + b"." + body,
                                            hashlib.sha256).digest()).rstrip(b"=")
    return (hdr + b"." + body + b"." + sig).decode()


def verify_token(secret: bytes, token: str) -> dict:
    hdr, body, sig = token.encode().split(b".")
    exp = base64.urlsafe_b64encode(hmac.new(secret, hdr + b"." + body,
                                            hashlib.sha256).digest()).rstrip(b"=")
    if not hmac.compare_digest(exp, sig):
        raise MCPError(-32001, "invalid token")
    pad = b"=" * (-len(body) % 4)
    return json.loads(base64.urlsafe_b64decode(body + pad))


# ---------------------------------------------------------- JSON schema ---
_TYPES = {"number": (int, float), "integer": (int,), "string": (str,),
          "boolean": (bool,), "array": (list,), "object": (dict,)}


def validate(schema: dict, value: Any, path="$"):
    """Subset of JSON-Schema used by tool inputSchema definitions."""
    t = schema.get("type")
    if t:
        ok = isinstance(value, _TYPES[t]) and not (
            t in ("number", "integer") and isinstance(value, bool))
        if not ok:
            raise MCPError(-32602, f"{path}: expected {t}")
    if "minimum" in schema and value < schema["minimum"]:
        raise MCPError(-32602, f"{path}: below minimum")
    if "maximum" in schema and value > schema["maximum"]:
        raise MCPError(-32602, f"{path}: above maximum")
    if "enum" in schema and value not in schema["enum"]:
        raise MCPError(-32602, f"{path}: not in enum")
    if t == "array":
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            raise MCPError(-32602, f"{path}: too many items")
        for j, v in enumerate(value):
            validate(schema.get("items", {}), v, f"{path}[{j}]")
    if t == "object":
        for r in schema.get("required", []):
            if r not in value:
                raise MCPError(-32602, f"{path}.{r}: required")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            extra = set(value) - set(props)
            if extra:
                raise MCPError(-32602, f"{path}: unexpected {sorted(extra)}")
        for k, v in value.items():
            if k in props:
                validate(props[k], v, f"{path}.{k}")


# --------------------------------------------------------------- server ---
@dataclass
class Tool:
    name: str
    description: str
    input_schema: dict
    handler: Callable[[dict], Any]
    scope: str
    api_latency: Callable[[np.random.Generator], float]


@dataclass
class Resource:
    uri: str
    name: str
    reader: Callable[[], Any]
    scope: str = "telemetry:read"


@dataclass
class MCPServer:
    name: str
    secret: bytes
    tools: dict = field(default_factory=dict)
    resources: dict = field(default_factory=dict)

    def add_tool(self, tool: Tool):
        self.tools[tool.name] = tool

    def add_resource(self, res: Resource):
        self.resources[res.uri] = res

    def handle(self, raw: str, token: str, rng) -> tuple[str, float, float]:
        """Process one JSON-RPC request; return (response, t_auth, t_api)."""
        t0 = time.perf_counter()
        claims = verify_token(self.secret, token)
        t_auth = time.perf_counter() - t0
        scopes = set(claims["scope"].split())
        req = json.loads(raw)
        method, params, rid = req["method"], req.get("params", {}), req["id"]
        t_api = 0.0
        try:
            if method == "initialize":
                result = {"protocolVersion": PROTOCOL_VERSION,
                          "capabilities": {"tools": {"listChanged": False},
                                           "resources": {"subscribe": True}},
                          "serverInfo": {"name": self.name, "version": "1.0"}}
            elif method == "tools/list":
                result = {"tools": [{"name": t.name, "description": t.description,
                                     "inputSchema": t.input_schema}
                                    for t in self.tools.values()]}
            elif method == "resources/list":
                result = {"resources": [{"uri": r.uri, "name": r.name,
                                         "mimeType": "application/json"}
                                        for r in self.resources.values()]}
            elif method == "resources/read":
                r = self.resources.get(params["uri"])
                if r is None:
                    raise MCPError(-32002, "resource not found")
                if r.scope not in scopes:
                    raise MCPError(-32001, "insufficient scope")
                result = {"contents": [{"uri": r.uri, "mimeType": "application/json",
                                        "text": json.dumps(r.reader())}]}
            elif method == "tools/call":
                tool = self.tools.get(params["name"])
                if tool is None:
                    raise MCPError(-32602, f"unknown tool {params['name']}")
                if tool.scope not in scopes:
                    raise MCPError(-32001, "insufficient scope")
                validate(tool.input_schema, params.get("arguments", {}))
                out = tool.handler(params.get("arguments", {}))
                t_api = tool.api_latency(rng)
                result = {"content": [{"type": "text", "text": json.dumps(out)}],
                          "isError": False}
            else:
                raise MCPError(-32601, "method not found")
            resp = {"jsonrpc": "2.0", "id": rid, "result": result}
        except MCPError as e:
            resp = {"jsonrpc": "2.0", "id": rid,
                    "error": {"code": e.code, "message": e.message}}
        return json.dumps(resp), t_auth, t_api


# --------------------------------------------------------------- client ---
@dataclass
class MCPClient:
    """Agent-side MCP client with a Streamable-HTTP latency model."""
    server: MCPServer
    token: str
    rng: np.random.Generator
    rtt_range: tuple = (0.001, 0.004)   # intra-edge LAN RTT [s]
    lan_bps: float = 1e9
    log: list = field(default_factory=list)

    def request(self, method: str, params: dict | None = None):
        msg = {"jsonrpc": "2.0", "id": next(_ids), "method": method}
        if params is not None:
            msg["params"] = params
        raw = json.dumps(msg)
        t0 = time.perf_counter()
        resp, t_auth, t_api = self.server.handle(raw, self.token, self.rng)
        t_handler = time.perf_counter() - t0
        t_net = self.rng.uniform(*self.rtt_range) + 8 * (len(raw) + len(resp)) / self.lan_bps
        latency = t_net + t_handler + t_api
        self.log.append({"method": method, "bytes": len(raw) + len(resp),
                         "latency": latency, "t_auth": t_auth, "t_api": t_api})
        out = json.loads(resp)
        if "error" in out:
            raise MCPError(out["error"]["code"], out["error"]["message"])
        return out["result"], latency

    def call_tool(self, name, arguments):
        res, lat = self.request("tools/call", {"name": name, "arguments": arguments})
        return json.loads(res["content"][0]["text"]), lat

    def read(self, uri):
        res, lat = self.request("resources/read", {"uri": uri})
        return json.loads(res["contents"][0]["text"]), lat
