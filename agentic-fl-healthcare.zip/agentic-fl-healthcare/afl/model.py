"""Two-layer MLP diagnostic model implemented in NumPy (flat parameter vector)."""
from __future__ import annotations

import numpy as np


class MLP:
    def __init__(self, d_in, d_hidden, n_classes, seed=0):
        self.shapes = [(d_in, d_hidden), (d_hidden,), (d_hidden, n_classes),
                       (n_classes,)]
        self.sizes = [int(np.prod(s)) for s in self.shapes]
        rng = np.random.default_rng(seed)
        w1 = rng.normal(0, np.sqrt(2.0 / d_in), (d_in, d_hidden))
        w2 = rng.normal(0, np.sqrt(2.0 / d_hidden), (d_hidden, n_classes))
        self.theta = np.concatenate([w1.ravel(), np.zeros(d_hidden),
                                     w2.ravel(), np.zeros(n_classes)])

    @property
    def n_params(self):
        return self.theta.size

    def unpack(self, theta):
        out, i = [], 0
        for s, n in zip(self.shapes, self.sizes):
            out.append(theta[i:i + n].reshape(s))
            i += n
        return out

    def forward(self, theta, X):
        w1, b1, w2, b2 = self.unpack(theta)
        h = np.maximum(0, X @ w1 + b1)
        z = h @ w2 + b2
        z = z - z.max(1, keepdims=True)
        p = np.exp(z)
        return h, p / p.sum(1, keepdims=True)

    def grad(self, theta, X, y, l2=1e-4):
        w1, b1, w2, b2 = self.unpack(theta)
        h, p = self.forward(theta, X)
        n = len(y)
        dz = p.copy()
        dz[np.arange(n), y] -= 1
        dz /= n
        gw2 = h.T @ dz + l2 * w2
        gb2 = dz.sum(0)
        dh = (dz @ w2.T) * (h > 0)
        gw1 = X.T @ dh + l2 * w1
        gb1 = dh.sum(0)
        return np.concatenate([gw1.ravel(), gb1, gw2.ravel(), gb2])

    def local_train(self, theta, X, y, epochs=2, lr=0.1, batch=16, rng=None):
        rng = rng or np.random.default_rng()
        th = theta.copy()
        for _ in range(epochs):
            idx = rng.permutation(len(y))
            for s in range(0, len(y), batch):
                b = idx[s:s + batch]
                th -= lr * self.grad(th, X[b], y[b])
        return th

    def per_example_grads(self, theta, X, y):
        w1, b1, w2, b2 = self.unpack(theta)
        h, p = self.forward(theta, X)
        dz = p.copy()
        dz[np.arange(len(y)), y] -= 1
        gw2 = np.einsum("bh,bc->bhc", h, dz)
        dh = (dz @ w2.T) * (h > 0)
        gw1 = np.einsum("bd,bh->bdh", X, dh)
        B = len(y)
        return np.concatenate([gw1.reshape(B, -1), dh, gw2.reshape(B, -1), dz], axis=1)

    def local_train_dp(self, theta, X, y, epochs, lr, clip, sigma, batch=16, rng=None):
        """DP-SGD (Abadi et al., 2016): per-example clipping + Gaussian noise.
        Returns (theta, steps, sampling_rate) for the RDP accountant."""
        rng = rng or np.random.default_rng()
        th = theta.copy()
        n = len(y)
        q = min(1.0, batch / n)
        steps = 0
        for _ in range(epochs):
            for _ in range(max(1, int(np.ceil(n / batch)))):
                b = np.where(rng.random(n) < q)[0]          # Poisson subsampling
                if len(b) == 0:
                    steps += 1
                    continue
                G = self.per_example_grads(th, X[b], y[b])
                G *= np.minimum(1.0, clip / (np.linalg.norm(G, axis=1, keepdims=True) + 1e-12))
                g = (G.sum(0) + rng.normal(0, sigma * clip, G.shape[1])) / max(q * n, 1.0)
                th -= lr * g
                steps += 1
        return th, steps, q

    def accuracy(self, theta, X, y):
        return float((self.forward(theta, X)[1].argmax(1) == y).mean())

    def macro_f1(self, theta, X, y):
        pred = self.forward(theta, X)[1].argmax(1)
        f1s = []
        for c in np.unique(y):
            tp = np.sum((pred == c) & (y == c))
            fp = np.sum((pred == c) & (y != c))
            fn = np.sum((pred != c) & (y == c))
            f1s.append(2 * tp / max(2 * tp + fp + fn, 1))
        return float(np.mean(f1s))
