"""System model of the healthcare edge network and its latency components.

Notation follows Section 3 (Eqs. 1-5) of the paper:
  i  - IoMT client (hospital gateway / wearable hub), i in N
  k  - edge server (MEC host co-located with an O-RAN gNB), k in K
  f_i     CPU frequency of client i [Hz]
  c       CPU cycles needed per training sample
  D_i     local dataset size; e local epochs
  S       model payload [bit]
  b_i     fraction of the cell bandwidth B allocated to client i
  g_i     channel gain (path loss x shadowing x Rayleigh fading)
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np


def dbm_to_w(dbm):
    return 10 ** ((dbm - 30) / 10)


@dataclass
class NetConfig:
    n_clients: int = 20
    n_edges: int = 3
    bandwidth_hz: float = 10e6          # B per edge cell
    p_tx_w: float = 0.2                 # 23 dBm client transmit power
    p_bs_w: float = 10.0                # 40 dBm gNB transmit power
    n0_dbm_hz: float = -174.0
    noise_figure_db: float = 9.0
    d_min_m: float = 50.0
    d_max_m: float = 400.0
    shadow_db: float = 8.0
    f_min_hz: float = 0.5e9
    f_max_hz: float = 2.0e9
    straggler_frac: float = 0.15
    straggler_slowdown: float = 0.25
    cycles_per_sample: float = 2.0e7    # deployment profile (1D-CNN scale)
    model_bits: float = 8.0e6           # S = 8 Mbit (~250k fp32 params)
    kappa: float = 1e-28                # effective switched capacitance
    f_edge_hz: float = 3.0e9
    agg_cycles_per_param: float = 20.0
    sec_cycles_per_param: float = 60.0
    backhaul_bps: float = 1e9
    backhaul_rtt_s: float = 0.010
    mu_edge: float = 100.0              # edge service rate [jobs/s]
    lam_range: tuple = (20.0, 85.0)     # background inference load [req/s]
    dropout_prob: float = 0.05
    seed: int = 0


@dataclass
class EdgeNetwork:
    cfg: NetConfig
    rng: np.random.Generator = field(init=False)

    def __post_init__(self):
        c = self.cfg
        self.rng = np.random.default_rng(c.seed)
        n = c.n_clients
        self.edge_of = self.rng.integers(0, c.n_edges, n)
        self.dist = self.rng.uniform(c.d_min_m, c.d_max_m, n)
        pl_db = 128.1 + 37.6 * np.log10(self.dist / 1000.0)
        sh_db = self.rng.normal(0, c.shadow_db, n)
        self.large_scale = 10 ** (-(pl_db + sh_db) / 10)
        self.f_nominal = self.rng.uniform(c.f_min_hz, c.f_max_hz, n)
        strag = self.rng.random(n) < c.straggler_frac
        self.f_nominal[strag] *= c.straggler_slowdown
        self.noise_w_hz = dbm_to_w(c.n0_dbm_hz + c.noise_figure_db)
        self.lam = self.rng.uniform(*c.lam_range, c.n_edges)
        self.step()

    # ----- per-round stochastic state (what the Monitor agent observes) -----
    def step(self):
        c = self.cfg
        n = c.n_clients
        self.gain = self.large_scale * self.rng.exponential(1.0, n)  # Rayleigh
        self.f_now = self.f_nominal * self.rng.uniform(0.6, 1.0, n)
        self.available = self.rng.random(n) > c.dropout_prob
        self.lam = np.clip(self.lam + self.rng.normal(0, 4.0, c.n_edges),
                           c.lam_range[0], c.lam_range[1])
        self.battery = self.rng.uniform(0.2, 1.0, n)

    # ----- latency components (Eqs. 1-5 of the paper) -----
    def t_cmp(self, i, D, epochs):
        return epochs * D * self.cfg.cycles_per_sample / self.f_now[i]

    def e_cmp(self, i, D, epochs):
        return self.cfg.kappa * epochs * self.cfg.cycles_per_sample * D * self.f_now[i] ** 2

    def rate_up(self, i, b):
        B = self.cfg.bandwidth_hz
        b = np.maximum(b, 1e-12)
        snr = self.cfg.p_tx_w * self.gain[i] / (self.noise_w_hz * b * B)
        return b * B * np.log2(1 + snr)

    def t_up(self, i, b, bits=None):
        bits = self.cfg.model_bits if bits is None else bits
        return bits / self.rate_up(i, b)

    def t_down(self, idx, bits=None):
        """Broadcast over the full band; limited by the worst selected link."""
        if len(idx) == 0:
            return 0.0
        bits = self.cfg.model_bits if bits is None else bits
        B = self.cfg.bandwidth_hz
        g = np.min(self.gain[idx])
        r = B * np.log2(1 + self.cfg.p_bs_w * g / (self.noise_w_hz * B))
        return bits / r

    def t_queue(self, k):
        """M/M/1 mean waiting time of an FL job at edge k (Eq. 4)."""
        mu, lam = self.cfg.mu_edge, self.lam[k]
        return lam / (mu * (mu - lam))

    def t_agg(self, n_updates, n_params):
        return n_updates * n_params * self.cfg.agg_cycles_per_param / self.cfg.f_edge_hz

    def t_sec(self, n_updates, n_params):
        return n_updates * n_params * self.cfg.sec_cycles_per_param / self.cfg.f_edge_hz

    def t_backhaul(self, bits=None):
        bits = self.cfg.model_bits if bits is None else bits
        return bits / self.cfg.backhaul_bps + self.cfg.backhaul_rtt_s

    def telemetry(self, i):
        return {"client": int(i), "edge": int(self.edge_of[i]),
                "cpu_ghz": round(float(self.f_now[i]) / 1e9, 3),
                "gain_db": round(float(10 * np.log10(self.gain[i])), 2),
                "available": bool(self.available[i]),
                "battery": round(float(self.battery[i]), 2)}
