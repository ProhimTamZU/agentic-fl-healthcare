"""Planner tools: latency-optimal bandwidth allocation and client selection.

min_{b, T} T  s.t.  t_i^cmp + S / r_i(b_i) <= T,  sum_i b_i <= 1,  b_i >= 0
r_i(b) = b B log2(1 + p g_i / (N0 b B)) is increasing and concave in b, so for a
fixed T each b_i(T) is found by bisection and T* by an outer bisection on
sum_i b_i(T) = 1 (Section 4.2, Eqs. 12-13 of the paper).
"""
from __future__ import annotations

import numpy as np


def _b_needed(net, idx, t_cmp, T, bits, iters=40):
    need = bits / np.maximum(T - t_cmp, 1e-9)        # required rate [bit/s]
    lo, hi = np.zeros(len(idx)), np.ones(len(idx))
    feasible = net.rate_up(idx, hi) >= need
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        ok = net.rate_up(idx, mid) >= need
        hi = np.where(ok, mid, hi)
        lo = np.where(ok, lo, mid)
    return np.where(feasible, hi, np.inf)


def minmax_bandwidth(net, idx, t_cmp, bits=None, iters=40):
    """Return (b, T*) minimising the slowest finish time inside one cell."""
    idx = np.asarray(idx)
    if len(idx) == 0:
        return np.array([]), 0.0
    bits = net.cfg.model_bits if bits is None else bits
    lo = float(np.max(t_cmp))
    hi = lo + float(np.max(bits / net.rate_up(idx, np.full(len(idx), 1.0 / len(idx)))))
    hi = max(hi, lo + 1e-3) * 1.01
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        if np.sum(_b_needed(net, idx, t_cmp, mid, bits)) <= 1.0:
            hi = mid
        else:
            lo = mid
    b = _b_needed(net, idx, t_cmp, hi, bits)
    b = b / max(b.sum(), 1.0)
    return b, hi


def equal_bandwidth(idx):
    return np.full(len(idx), 1.0 / max(len(idx), 1))


def utility(net, clients_D, epochs, reputation, idx):
    """Trust-weighted statistical utility per unit predicted latency."""
    D = np.asarray([clients_D[i] for i in idx], dtype=float)
    t = np.asarray([net.t_cmp(i, clients_D[i], epochs) for i in idx])
    t = t + np.asarray([net.t_up(i, 1.0 / 6) for i in idx])
    return reputation[idx] * np.sqrt(D) / t
