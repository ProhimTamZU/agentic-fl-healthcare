"""Threat models, update screening, robust aggregation, privacy accounting and
measured cryptographic overheads."""
from __future__ import annotations

import hashlib
import hmac
import math
import os
import time

import numpy as np


# --------------------------------------------------------------- attacks ---
def poison_update(delta, kind, rng, scale=4.0):
    """Model-poisoning transforms applied by Byzantine clients."""
    if kind == "signflip":
        return -scale * delta
    if kind == "gaussian":
        return rng.normal(0, 1, delta.shape) * scale * np.linalg.norm(delta) / np.sqrt(delta.size)
    if kind == "scaling":           # boosted model replacement
        return 10.0 * delta
    return delta                     # 'labelflip' handled in data space


def flip_labels(y, n_classes):
    """Clinically harmful flip: pathologic->normal, suspect->pathologic, normal->suspect."""
    return (y + 1) % n_classes if n_classes > 2 else 1 - y


# ------------------------------------------------------------ screening ---
def screen_updates(deltas, steps=None, ref=None, tau=-1.3, w_norm=2.0, w_cos=1.0):
    """Security-agent anomaly score for each update (Eqs. 14-15 of the paper).

        z_i = log( (||D_i|| / sqrt(n_i)) / med_j(||D_j|| / sqrt(n_j)) )
        s_i = cos(D_i, m_{t-1}) - w_norm * max(0, z_i)

    n_i is the number of local SGD steps reported by client i (honest update
    norms grow ~sqrt(n_i)); m_{t-1} is the momentum of previously accepted
    global updates (per-round median at t=0). Flag if s_i < tau.
    Returns (flags, scores, median_norm).
    """
    U = np.stack(deltas)
    steps = np.ones(len(deltas)) if steps is None else np.asarray(steps, float)
    ref = np.median(U, axis=0) if ref is None else ref
    norms = np.linalg.norm(U, axis=1) + 1e-12
    un = norms / np.sqrt(steps)
    z = np.log(un / np.median(un))
    cos = U @ ref / (norms * (np.linalg.norm(ref) + 1e-12))
    s = w_cos * cos - w_norm * np.maximum(0.0, z)
    return s < tau, s, float(np.median(norms))


def validation_screen(model, theta, deltas, root, kappa=2.0, abs_tol=0.3):
    """Loss-impact test on the edge-held root set (Eq. 16 of the paper):
    dl_i = L_bal(theta + D_i) - L_bal(theta), with L_bal the class-balanced
    cross-entropy (so clients rich in rare pathologies are not penalised);
    flag if dl_i > abs_tol and dl_i > med(dl) + kappa * MAD(dl).
    Returns (flags, dl)."""
    X, y = root
    cls = np.unique(y)
    cw = np.zeros(int(y.max()) + 1)
    cw[cls] = 1.0 / np.array([np.sum(y == c) for c in cls])
    w = cw[y] / cw[y].sum()

    def loss(th):
        p = model.forward(th, X)[1]
        return float(-np.sum(w * np.log(p[np.arange(len(y)), y] + 1e-12)))
    base = loss(theta)
    dl = np.array([loss(theta + d) - base for d in deltas])
    m = np.median(dl)
    mad = np.median(np.abs(dl - m)) * 1.4826 + 1e-6
    return (dl > abs_tol) & (dl > m + kappa * mad), dl


def trimmed_mean(deltas, beta=0.2):
    U = np.sort(np.stack(deltas), axis=0)
    k = int(math.floor(beta * len(deltas)))
    return U[k:len(deltas) - k].mean(0) if len(deltas) > 2 * k else U.mean(0)


def weighted_trimmed_mean(U, w, beta=0.1):
    """Coordinate-wise trimmed mean that keeps per-client weights for the
    retained entries (defence-in-depth after screening)."""
    n = len(U)
    k = int(math.floor(beta * n))
    if k == 0:
        return np.average(U, axis=0, weights=w / w.sum())
    order = np.argsort(U, axis=0)
    keep = np.zeros_like(U, dtype=bool)
    np.put_along_axis(keep, order[k:n - k], True, axis=0)
    W = keep * w[:, None]
    return (U * W).sum(0) / W.sum(0)


def clip(delta, c):
    n = np.linalg.norm(delta)
    return delta * min(1.0, c / (n + 1e-12))


# ------------------------------------------------------- DP accounting ---
def _log_add(a, b):
    m = max(a, b)
    return m + math.log(math.exp(a - m) + math.exp(b - m))


def rdp_subsampled_gaussian(q, sigma, alpha: int):
    """RDP of the Poisson-subsampled Gaussian mechanism at integer order alpha
    (Mironov, Talwar & Zhang, 2019)."""
    if q == 0:
        return 0.0
    if q == 1.0:
        return alpha / (2 * sigma ** 2)
    log_a = -math.inf
    for k in range(alpha + 1):
        log_coef = (math.lgamma(alpha + 1) - math.lgamma(k + 1) - math.lgamma(alpha - k + 1)
                    + k * math.log(q) + (alpha - k) * math.log(1 - q))
        log_a = _log_add(log_a, log_coef + (k * k - k) / (2 * sigma ** 2))
    return log_a / (alpha - 1)


def epsilon(q, sigma, steps, delta=1e-5, orders=range(2, 129)):
    """(epsilon, delta)-DP after `steps` rounds of client-level DP-FedAvg."""
    if sigma <= 0:
        return math.inf
    return min(steps * rdp_subsampled_gaussian(q, sigma, a) + math.log(1 / delta) / (a - 1)
               for a in orders)


def sigma_for_budget(q, steps, eps_target, delta=1e-5):
    lo, hi = 0.3, 50.0
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if epsilon(q, mid, steps, delta) > eps_target:
            lo = mid
        else:
            hi = mid
    return hi


# ------------------------------------------------ measured crypto cost ---
def measure_crypto(payload_bytes: int, reps: int = 5) -> dict:
    """Wall-clock cost of AES-256-GCM + HMAC-SHA256 on this host."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    data = os.urandom(payload_bytes)
    key, mkey = AESGCM.generate_key(256), os.urandom(32)
    aes = AESGCM(key)
    enc, dec, mac = [], [], []
    for _ in range(reps):
        nonce = os.urandom(12)
        t = time.perf_counter(); ct = aes.encrypt(nonce, data, None); enc.append(time.perf_counter() - t)
        t = time.perf_counter(); aes.decrypt(nonce, ct, None); dec.append(time.perf_counter() - t)
        t = time.perf_counter(); hmac.new(mkey, ct, hashlib.sha256).digest(); mac.append(time.perf_counter() - t)
    return {"aes_gcm_enc_s": float(np.median(enc)), "aes_gcm_dec_s": float(np.median(dec)),
            "hmac_sha256_s": float(np.median(mac)), "payload_bytes": payload_bytes}
