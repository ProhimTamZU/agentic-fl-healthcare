"""Draw Fig. 1: agentic FL architecture over the healthcare edge network."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figures")
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7})

C = {"cloud": "#E8EEF7", "edge": "#F4F1EA", "agent": "#FFFFFF", "mcp": "#E6F2EC",
     "api": "#FBEDE7", "dev": "#EEF0F2", "ink": "#22313F", "obs": "#2F6DB5",
     "act": "#C0392B", "fl": "#1E8A5A", "line": "#8A96A3"}


def box(ax, x, y, w, h, text, fc, ec=C["line"], lw=0.8, fs=7, bold=False, r=0.012, color=None, va="center"):
    p = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.004,rounding_size={r}",
                       fc=fc, ec=ec, lw=lw)
    ax.add_patch(p)
    if text:
        ax.text(x + w / 2, y + h / 2 if va == "center" else y + h - 0.012, text, ha="center", va=va,
                fontsize=fs, color=color or C["ink"], fontweight="bold" if bold else "normal",
                linespacing=1.15)
    return p


def arrow(ax, p0, p1, color, ls="-", lw=1.1, rad=0.0, both=False):
    a = FancyArrowPatch(p0, p1, arrowstyle="<|-|>" if both else "-|>", mutation_scale=7,
                        color=color, lw=lw, linestyle=ls,
                        connectionstyle=f"arc3,rad={rad}", shrinkA=1, shrinkB=1)
    ax.add_patch(a)


def poly(ax, pts, color, ls="-", lw=1.0):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1] + (xs[-1],), ys, color=color, lw=lw, linestyle=ls, solid_capstyle="round")
    ax.add_patch(FancyArrowPatch(pts[-2], pts[-1], arrowstyle="-|>", mutation_scale=7, color=color,
                                 lw=lw, linestyle=ls, shrinkA=0, shrinkB=1))


fig = plt.figure(figsize=(7.1, 3.9), dpi=300)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")

for y, t in [(0.885, "CLOUD"), (0.525, "EDGE SITE"), (0.155, "DEVICES")]:
    ax.text(0.017, y, t, fontsize=6, fontweight="bold", color="#5B6770", va="center", rotation=90, ha="center")

# ---------------- cloud tier ----------------
box(ax, 0.03, 0.82, 0.94, 0.15, "", C["cloud"])
box(ax, 0.05, 0.84, 0.20, 0.11, "Global aggregator\n(cross-edge FedAvg)", C["agent"])
box(ax, 0.29, 0.84, 0.25, 0.11, "LLM strategist (slow loop)\nobjectives, risk policy,\nevent-triggered re-planning", C["agent"])
box(ax, 0.58, 0.84, 0.17, 0.11, "Policy store\nRBAC / OAuth 2.1 scopes", C["agent"])
box(ax, 0.79, 0.84, 0.16, 0.11, "Audit log\ntool-call trace,\nprivacy ledger", C["agent"])

# ---------------- edge tier ----------------
box(ax, 0.03, 0.27, 0.94, 0.525, "", C["edge"])
box(ax, 0.05, 0.535, 0.50, 0.245, "", "#FFFDF8", ec="#B9A88A")
ax.text(0.30, 0.758, "Edge agentic control plane (fast loop, every round)", ha="center", fontsize=6.6,
        fontweight="bold", color=C["ink"])
ag = [("Monitor\n(perceive)", 0.062), ("Planner\n(reason/plan)", 0.183),
      ("Security\n(verify)", 0.304), ("Executor\n(act + guard)", 0.425)]
for t, x in ag:
    box(ax, x, 0.635, 0.108, 0.09, t, C["agent"], ec="#7F8C8D", fs=6.3)
for (t1, x1), (t2, x2) in zip(ag[:-1], ag[1:]):
    arrow(ax, (x1 + 0.108, 0.68), (x2, 0.68), C["ink"], lw=0.9)
ax.text(0.30, 0.557, "closed loop: observe \u2192 plan \u2192 verify \u2192 act \u2192 re-observe",
        ha="center", fontsize=5.9, style="italic", color="#5B6770")

box(ax, 0.58, 0.535, 0.37, 0.245, "", C["mcp"], ec="#5FA37F")
ax.text(0.765, 0.758, "MCP servers (JSON-RPC 2.0, Streamable HTTP)", ha="center", fontsize=6.4,
        fontweight="bold", color=C["ink"])
box(ax, 0.772, 0.585, 0.165, 0.155,
    "Resources\n(resources/read, subscribe)\nedge://k/telemetry\nfl://security/reputation", C["agent"], fs=5.6)
box(ax, 0.592, 0.585, 0.165, 0.155,
    "Tools (tools/call)\nran.set_bandwidth_shares\nsdn.install_flows\nfl.configure_round\nfl.quarantine_client\nk8s.migrate_aggregator",
    C["agent"], fs=5.3)
ax.text(0.765, 0.545, "token scope check \u2192 JSON-Schema \u2192 handler", ha="center",
        fontsize=5.7, color="#2E6B4E")

# agent <-> MCP
poly(ax, [(0.83, 0.585), (0.83, 0.567), (0.57, 0.567), (0.57, 0.60), (0.116, 0.60), (0.116, 0.633)],
     C["obs"], ls=(0, (2, 1.2)), lw=0.9)
arrow(ax, (0.533, 0.69), (0.592, 0.69), C["act"], lw=1.0)

# API bus
ax.plot([0.12, 0.88], [0.49, 0.49], color=C["act"], lw=1.2)
ax.plot([0.12, 0.90], [0.465, 0.465], color=C["obs"], lw=1.0, ls=(0, (2, 1.2)))
arrow(ax, (0.65, 0.585), (0.65, 0.49), C["act"], lw=1.0)
arrow(ax, (0.90, 0.465), (0.90, 0.585), C["obs"], ls=(0, (2, 1.2)), lw=0.9)
ax.text(0.36, 0.505, "southbound network / platform APIs (solid: act bus, dashed: observe bus)",
        ha="center", fontsize=5.8, color="#8E4B34")
apis = [("O-RAN Near-RT RIC\nA1 policy / E2 KPM", 0.05), ("SDN controller\nREST north-bound", 0.285),
        ("FL server\n(gRPC, Flower-style)", 0.52), ("Kubernetes API\n(edge pods)", 0.755)]
for t, x in apis:
    box(ax, x, 0.31, 0.195, 0.09, t, C["api"], ec="#D08C74", fs=6.2)
    arrow(ax, (x + 0.07, 0.49), (x + 0.07, 0.402), C["act"], lw=0.8)
    arrow(ax, (x + 0.125, 0.402), (x + 0.125, 0.465), C["obs"], ls=(0, (2, 1.2)), lw=0.8)

# cloud <-> edge
arrow(ax, (0.36, 0.84), (0.237, 0.725), C["ink"], lw=0.8, both=True)
ax.text(0.30, 0.80, "strategy", ha="right", fontsize=5.7, color=C["ink"])
arrow(ax, (0.665, 0.84), (0.50, 0.725), "#7F8C8D", lw=0.8)
ax.text(0.665, 0.80, "scopes", fontsize=5.7, color="#7F8C8D")
arrow(ax, (0.15, 0.78), (0.15, 0.84), C["fl"], lw=1.1, both=True)
ax.text(0.157, 0.803, "edge models", fontsize=5.7, color=C["fl"])

# ---------------- device tier ----------------
box(ax, 0.03, 0.07, 0.94, 0.175, "", C["dev"])
devs = [("Wearable ECG\n/ SpO\u2082 patch", 0.05), ("Fetal CTG\nmonitor", 0.205), ("Bedside\nmonitor", 0.36),
        ("Hospital\ngateway", 0.515), ("Clinic\nedge PC", 0.67), ("Malicious\nclient", 0.825)]
for t, x in devs:
    ec = C["act"] if "Malicious" in t else "#95A5A6"
    box(ax, x, 0.09, 0.125, 0.08, t, C["agent"], ec=ec, fs=6.1, lw=1.0 if "Mal" in t else 0.8)
ax.text(0.5, 0.215, "local training on private EHR / sensor data \u2014 raw data never leaves the site",
        ha="center", fontsize=6.0, color="#5B6770")
arrow(ax, (0.60, 0.245), (0.60, 0.31), C["fl"], lw=1.6, both=True)
ax.text(0.607, 0.268, "encrypted updates / global model", fontsize=5.7, color=C["fl"])
arrow(ax, (0.13, 0.245), (0.13, 0.31), C["obs"], ls=(0, (2, 1.2)), lw=1.2)
ax.text(0.137, 0.268, "E2 KPM: CQI, PRB, CPU, battery", fontsize=5.7, color=C["obs"])
arrow(ax, (0.36, 0.31), (0.36, 0.245), C["act"], lw=1.2)
ax.text(0.367, 0.268, "PRB shares, flow rules", fontsize=5.7, color=C["act"])

# legend
for i, (c, ls, t) in enumerate([(C["obs"], (0, (2, 1.2)), "observe (telemetry, KPM, reputation)"),
                                (C["act"], "-", "act (guarded MCP tool call \u2192 API)"),
                                (C["fl"], "-", "federated-learning traffic")]):
    xx = 0.06 + i * 0.31
    ax.add_patch(FancyArrowPatch((xx, 0.035), (xx + 0.04, 0.035), arrowstyle="-|>", mutation_scale=7,
                                 color=c, lw=1.1, linestyle=ls))
    ax.text(xx + 0.047, 0.035, t, va="center", fontsize=6.0, color=C["ink"])

fig.savefig(os.path.join(OUT, "fig1_architecture.png"), dpi=300)
print("saved")
