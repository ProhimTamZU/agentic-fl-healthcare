"""Turn results/all_results.json into the paper's figures and tables."""
import json
import os
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = json.load(open(os.path.join(ROOT, "results", "all_results.json")))
FIG = os.path.join(ROOT, "figures")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7, "axes.linewidth": 0.6,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "xtick.major.width": 0.6, "ytick.major.width": 0.6, "legend.frameon": False})
COL = {"FedAvg": "#8A96A3", "FedAvg-TM": "#C49A3A", "FedCS": "#2F6DB5", "AFL-Seq": "#9B59B6",
       "AFL": "#C0392B", "AFL-NoGuard": "#E67E22"}
MK = {"FedAvg": "o", "FedAvg-TM": "s", "FedCS": "^", "AFL-Seq": "D", "AFL": "*"}


def group(prefix):
    g = defaultdict(list)
    for k, v in RES.items():
        p = k.split("|")
        if p[0] == prefix:
            g[(p[1], p[2])].append(v)
    return g


main, byz, scale, inj, dp = (group(x) for x in ("main", "byz", "scale", "inject", "dp"))
tab = {}

# ---------- Table: accuracy / F1 / latency per scheme and attack ----------
rows = []
for s in ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL"]:
    for att in ["none", "signflip", "gaussian", "scaling", "labelflip"]:
        R = main[(s, att)]
        S = [r["summary"] for r in R]
        det = {k: sum(r["detection"][k] for r in R) for k in ["tp", "fp", "fn", "tn"]}
        q_prec = [len(set(r.get("quarantined", [])) & set(r["malicious"])) for r in R]
        q_fp = [len(set(r.get("quarantined", [])) - set(r["malicious"])) for r in R]
        tta = [x["tta_0.85"] for x in S]
        rows.append({"scheme": s, "attack": att,
                     "acc": np.mean([x["acc_final"] for x in S]), "acc_sd": np.std([x["acc_final"] for x in S]),
                     "f1": np.mean([x["f1_final"] for x in S]), "f1_sd": np.std([x["f1_final"] for x in S]),
                     "T_mean": np.mean([x["T_mean"] for x in S]), "T_p95": np.mean([x["T_p95"] for x in S]),
                     "wall": np.mean([x["wall"] for x in S]),
                     "tta85": np.mean([t for t in tta if t is not None]) if any(t is not None for t in tta) else None,
                     "tta85_hits": sum(t is not None for t in tta),
                     "ctrl_exposed": np.mean([x["ctrl_exposed"] for x in S]),
                     "ctrl_total": np.mean([x["ctrl_total"] for x in S]),
                     "dropped": np.mean([x["dropped"] for x in S]),
                     "tpr": det["tp"] / max(1, det["tp"] + det["fn"]) if s.startswith("AFL") else None,
                     "fpr": det["fp"] / max(1, det["fp"] + det["tn"]) if s.startswith("AFL") else None,
                     "q_mal": float(np.mean(q_prec)), "q_honest": float(np.mean(q_fp)),
                     "breakdown": {k: float(np.mean([x["breakdown"][k] for x in S])) for k in S[0]["breakdown"]}})
tab["main"] = rows

# ---------- Fig 2: accuracy vs wall-clock (sign-flip 20%) + latency breakdown ----------
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.1), gridspec_kw={"width_ratios": [1.15, 1]})
ax = axs[0]
grid = np.linspace(0, 800, 161)
for s in ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL"]:
    curves = []
    for r in main[(s, "signflip")]:
        w = np.array([c[0] for c in r["curve"]]); a = np.array([c[1] for c in r["curve"]])
        curves.append(np.interp(grid, w, a, left=np.nan, right=a[-1]))
    m = np.nanmean(curves, 0)
    ax.plot(grid, m, color=COL[s], lw=1.3 if s == "AFL" else 0.9, label=s)
ax.set_xlabel("Wall-clock training time (s)")
ax.set_ylabel("Test accuracy (CTG)")
ax.set_ylim(0.1, 0.95)
ax.axhline(0.85, color="#BBBBBB", lw=0.5, ls=":")
ax.legend(ncol=2, fontsize=6, loc="lower right")
ax.set_title("(a) Convergence under 20% sign-flip attackers", fontsize=7)

ax = axs[1]
comps = [("t_ctrl_exposed", "Agent control (exposed)", "#C0392B"), ("t_dn", "Downlink", "#7FB3D5"),
         ("t_train", "Local compute + uplink", "#2F6DB5"),
         ("t_q", "Edge queue", "#F5B041"), ("t_sec", "Security screening", "#8E44AD"),
         ("other", "Agg. + backhaul + crypto", "#7F8C8D")]
names = ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL"]
bd = {r["scheme"]: r["breakdown"] for r in rows if r["attack"] == "none"}
left = np.zeros(len(names))
for key, lab, c in comps:
    v = np.array([bd[n]["t_agg"] + bd[n]["t_bh"] + bd[n]["t_crypto"] if key == "other" else bd[n][key]
                  for n in names])
    ax.barh(names, v, left=left, color=c, label=lab, height=0.6)
    left += v
for i, v in enumerate(left):
    ax.text(v + 0.4, i, f"{v:.1f} s", va="center", fontsize=6)
ax.invert_yaxis()
ax.set_xlabel("Mean per-round latency $T_r$ (s), no attack")
ax.legend(fontsize=5.5, loc="lower right", ncol=1)
ax.set_xlim(0, max(left) * 1.18)
ax.set_title("(b) Per-round latency decomposition (Eq. 12)", fontsize=7)
fig.tight_layout(pad=0.3, w_pad=1.0)
fig.savefig(os.path.join(FIG, "fig2_convergence_latency.png"), dpi=300)

# ---------- Fig 3: robustness vs Byzantine fraction + scalability ----------
fig, axs = plt.subplots(1, 2, figsize=(7.0, 1.95))
ax = axs[0]
fr = [0.1, 0.2, 0.3, 0.4]
for s in ["FedAvg", "FedAvg-TM", "FedCS", "AFL"]:
    m, sd = [], []
    for f in fr:
        R = main[(s, "signflip")] if f == 0.2 else byz[(s, str(f))]
        a = [r["summary"]["f1_final"] for r in R]
        m.append(np.mean(a)); sd.append(np.std(a))
    ax.errorbar([100 * f for f in fr], m, yerr=sd, color=COL[s], marker=MK[s], ms=3.5, lw=0.9,
                capsize=1.5, label=s)
ax.set_xlabel("Byzantine clients (%)")
ax.set_ylabel("Macro-F1 (CTG)")
ax.legend(fontsize=6, ncol=2)
ax.set_title("(a) Robustness to sign-flip model poisoning", fontsize=7)
ax = axs[1]
Ns = [20, 40, 60, 80, 100]
for s in ["FedAvg", "FedCS", "AFL-Seq", "AFL"]:
    m = [np.mean([r["summary"]["T_mean"] for r in scale[(s, str(n))]]) for n in Ns]
    ax.plot(Ns, m, color=COL[s], marker=MK[s], ms=3.5, lw=0.9, label=s)
ax2 = ax.twinx()
ctl = [np.mean([r["summary"]["ctrl_total"] for r in scale[("AFL", str(n))]]) * 1000 for n in Ns]
ax2.bar(Ns, ctl, width=6, color="#C0392B", alpha=0.18)
ax2.set_ylabel("AFL control overhead, bars (ms)", fontsize=6.5)
ax2.set_ylim(0, 1800)
ax2.spines["top"].set_visible(False)
ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)
ax.set_xlabel("Number of IoMT clients $N$")
ax.set_ylabel("Mean round latency (s)")
ax.set_yscale("log")
ax.set_ylim(1, 3000)
ax.legend(fontsize=6, loc="upper center", ncol=4, columnspacing=0.8, handlelength=1.5)
ax.set_title("(b) Scalability", fontsize=7)
fig.tight_layout(pad=0.3, w_pad=1.2)
fig.savefig(os.path.join(FIG, "fig3_robustness_scalability.png"), dpi=300)

# ---------- injection / MCP / guard table ----------
inj_rows = {}
for s in ["AFL-NoGuard", "AFL"]:
    R = inj[(s, "0.2")]
    logs = [x for r in R for x in r["inject_log"]]
    by_layer = defaultdict(int)
    for x in logs:
        by_layer[x["blocked_by"] or "executed"] += 1
    inj_rows[s] = {"attempts": len(logs), "outcome": dict(by_layer),
                   "executed": sum(x["executed"] for x in logs),
                   "honest_quarantined": float(np.mean([len(set(r["quarantined"]) - set(r["malicious"])) for r in R])),
                   "exported_records": int(sum(r["exported_records"] for r in R)),
                   "f1": float(np.mean([r["summary"]["f1_final"] for r in R])),
                   "acc": float(np.mean([r["summary"]["acc_final"] for r in R])),
                   "T_mean": float(np.mean([r["summary"]["T_mean"] for r in R])),
                   "per_attack": defaultdict(lambda: [0, 0])}
    pa = defaultdict(lambda: [0, 0])
    for x in logs:
        pa[x["attack"]][0] += 1
        pa[x["attack"]][1] += int(not x["executed"])
    inj_rows[s]["per_attack"] = {k: v for k, v in pa.items()}
    if s == "AFL":
        inj_rows[s]["mcp"] = {k: float(np.mean([r["mcp"][k] for r in R])) for k in R[0]["mcp"]}
        inj_rows[s]["guard_check_s"] = float(np.mean([r["guard_check_s"] for r in R]))
tab["inject"] = inj_rows
tab["dp"] = {sg: {"rounds": float(np.mean([len(r["curve"]) for r in dp[("AFL", sg)]])),
                  "acc": float(np.mean([r["summary"]["acc_final"] for r in dp[("AFL", sg)]])),
                  "f1": float(np.mean([r["summary"]["f1_final"] for r in dp[("AFL", sg)]])),
                  "eps_max": float(np.mean([r["dp"]["eps_max"] for r in dp[("AFL", sg)]]))}
             for sg in ["1.0", "2.0"]}
tab["scale"] = {s: {n: {"T": float(np.mean([r["summary"]["T_mean"] for r in scale[(s, str(n))]])),
                        "ctrl": float(np.mean([r["summary"]["ctrl_total"] for r in scale[(s, str(n))]]))}
                    for n in Ns} for s in ["FedAvg", "FedCS", "AFL-Seq", "AFL"]}
tab["crypto"] = json.load(open(os.path.join(ROOT, "results", "crypto.json")))
json.dump(tab, open(os.path.join(ROOT, "results", "summary.json"), "w"), indent=1, default=float)
print("figures + results/summary.json written")


# ---------- Fig 2 (paper): four panels in one row ----------
plt.rcParams.update({"font.size": 6})
fig, axs = plt.subplots(1, 4, figsize=(7.0, 1.75), gridspec_kw={"width_ratios": [1, 1.05, 1, 1.05]})
ax = axs[0]
for s_ in ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL"]:
    curves = []
    for r in main[(s_, "signflip")]:
        w = np.array([c[0] for c in r["curve"]]); a = np.array([c[1] for c in r["curve"]])
        curves.append(np.interp(grid, w, a, left=np.nan, right=a[-1]))
    ax.plot(grid, np.nanmean(curves, 0), color=COL[s_], lw=1.2 if s_ == "AFL" else 0.8, label=s_)
ax.axhline(0.85, color="#BBBBBB", lw=0.5, ls=":")
ax.set_ylim(0.0, 0.95); ax.set_xlabel("Wall-clock time (s)"); ax.set_ylabel("Test accuracy")
ax.legend(fontsize=5, loc="lower right", handlelength=1.2, labelspacing=0.2)
ax.set_title("(a) Convergence, 20% sign-flip", fontsize=6.3)
ax = axs[1]
left = np.zeros(len(names))
comps4 = [("ctl", "Agent control", "#C0392B"), ("dn", "Downlink", "#7FB3D5"),
          ("trn", "Compute+uplink", "#2F6DB5"), ("oth", "Other", "#F5B041")]
for key, lab, c in comps4:
    v = np.array([{"ctl": bd[n_]["t_ctrl_exposed"], "dn": bd[n_]["t_dn"], "trn": bd[n_]["t_train"],
                   "oth": bd[n_]["t_q"] + bd[n_]["t_sec"] + bd[n_]["t_agg"] + bd[n_]["t_bh"] + bd[n_]["t_crypto"]}[key]
                  for n_ in names])
    ax.barh(names, v, left=left, color=c, label=lab, height=0.6); left += v
for i, v in enumerate(left):
    ax.text(v + 0.5, i, f"{v:.1f}", va="center", fontsize=5.3)
ax.invert_yaxis(); ax.set_xlim(0, 46); ax.set_xlabel("Mean round latency $T_r$ (s)")
ax.legend(fontsize=5, loc="lower right", handlelength=0.9, labelspacing=0.2, borderaxespad=0.2)
ax.set_title("(b) Latency decomposition, no attack", fontsize=6.3)
ax = axs[2]
for s_ in ["FedAvg", "FedAvg-TM", "FedCS", "AFL"]:
    m_, sd_ = [], []
    for f in fr:
        R = main[(s_, "signflip")] if f == 0.2 else byz[(s_, str(f))]
        a = [r["summary"]["f1_final"] for r in R]; m_.append(np.mean(a)); sd_.append(np.std(a))
    ax.errorbar([100 * f for f in fr], m_, yerr=sd_, color=COL[s_], marker=MK[s_], ms=2.5, lw=0.8, capsize=1.2, label=s_)
ax.set_xlabel("Byzantine clients (%)"); ax.set_ylabel("Macro-F1")
ax.legend(fontsize=5, loc="lower left", handlelength=1.2, labelspacing=0.2)
ax.set_title("(c) Robustness to sign-flip", fontsize=6.3)
ax = axs[3]
for s_ in ["FedAvg", "FedCS", "AFL-Seq", "AFL"]:
    ax.plot(Ns, [np.mean([r["summary"]["T_mean"] for r in scale[(s_, str(n_))]]) for n_ in Ns],
            color=COL[s_], marker=MK[s_], ms=2.5, lw=0.8, label=s_)
ax2 = ax.twinx()
ax2.bar(Ns, ctl, width=7, color="#C0392B", alpha=0.18); ax2.set_ylim(0, 1800)
ax2.set_ylabel("AFL control (ms, bars)", fontsize=5.5); ax2.spines["top"].set_visible(False)
ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)
ax.set_yscale("log"); ax.set_ylim(1, 3000); ax.set_xlabel("Number of clients $N$"); ax.set_ylabel("Round latency (s)")
ax.legend(fontsize=5, loc="upper center", ncol=2, handlelength=1.2, columnspacing=0.6, labelspacing=0.2)
ax.set_title("(d) Scalability", fontsize=6.3)
fig.tight_layout(pad=0.2, w_pad=0.6)
fig.savefig(os.path.join(FIG, "fig2_results_4panel.png"), dpi=300)
print("4-panel written")
