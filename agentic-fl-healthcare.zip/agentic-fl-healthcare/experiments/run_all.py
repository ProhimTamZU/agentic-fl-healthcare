"""Run every experiment reported in the paper and store raw results as JSON.

Usage:  python experiments/run_all.py [--seeds 5] [--rounds 100]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from afl import run, RunConfig, NetConfig  # noqa: E402
from afl.security import measure_crypto  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")
SCHEMES = ["FedAvg", "FedAvg-TM", "FedCS", "AFL-Seq", "AFL"]
ATTACKS = ["none", "signflip", "gaussian", "scaling", "labelflip"]


def _job(args):
    kw, net_kw, crypto = args
    cfg = RunConfig(**kw)
    net = NetConfig(n_clients=cfg.n_clients, seed=cfg.seed, **net_kw)
    o = run(cfg, net, crypto)
    L = o["log"]
    summary = {
        "acc_final": float(np.mean([l["acc"] for l in L[-5:]])),
        "f1_final": float(np.mean([l["f1"] for l in L[-5:]])),
        "T_mean": float(np.mean([l["T_r"] for l in L])),
        "T_p95": float(np.percentile([l["T_r"] for l in L], 95)),
        "wall": float(L[-1]["wall"]),
        "ctrl_exposed": float(np.mean([l["t_ctrl_exposed"] for l in L])),
        "ctrl_total": float(np.mean([l["t_ctrl_total"] for l in L])),
        "breakdown": {k: float(np.mean([l[k] for l in L])) for k in
                      ["t_ctrl_exposed", "t_dn", "t_train", "t_q", "t_sec", "t_agg", "t_bh", "t_crypto",
                       "t_llm", "t_obs", "t_opt", "t_act"]},
        "dropped": float(np.mean([l["dropped"] for l in L])),
        "n_upd": float(np.mean([l["n_upd"] for l in L])),
    }
    for tgt in (0.85, 0.88):
        hit = [l["wall"] for l in L if l["acc"] >= tgt]
        summary[f"tta_{tgt}"] = float(hit[0]) if hit else None
    keep = {k: o[k] for k in o if k not in ("log",)}
    keep["summary"] = summary
    keep["curve"] = [(l["wall"], l["acc"], l["f1"]) for l in L]
    return keep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--rounds", type=int, default=100)
    ap.add_argument("--workers", type=int, default=os.cpu_count())
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    seeds = range(a.seeds)
    t0 = time.time()

    crypto = measure_crypto(int(NetConfig().model_bits / 8))
    json.dump(crypto, open(os.path.join(OUT, "crypto.json"), "w"), indent=1)
    print("crypto", crypto, flush=True)

    jobs = {}
    # E1/E3: schemes x attacks (20% Byzantine)
    for s in SCHEMES:
        for att in ATTACKS:
            for sd in seeds:
                jobs[("main", s, att, sd)] = (dict(scheme=s, attack=att, seed=sd, rounds=a.rounds), {}, crypto)
    # E4: Byzantine fraction sweep (sign-flip)
    for s in ["FedAvg", "FedAvg-TM", "FedCS", "AFL"]:
        for bf in [0.1, 0.3, 0.4]:
            for sd in seeds:
                jobs[("byz", s, bf, sd)] = (dict(scheme=s, attack="signflip", byz_frac=bf, seed=sd,
                                                 rounds=a.rounds), {}, crypto)
    # E2: scalability (latency vs number of clients)
    for s in ["FedAvg", "FedCS", "AFL-Seq", "AFL"]:
        for n in [20, 40, 60, 80, 100]:
            for sd in list(seeds)[:3]:
                jobs[("scale", s, n, sd)] = (dict(scheme=s, attack="none", n_clients=n, seed=sd,
                                                  rounds=min(a.rounds, 60)), {}, crypto)
    # E5: agentic-security (tool-call injection), guard vs no guard
    for s in ["AFL-NoGuard", "AFL"]:
        for sd in seeds:
            jobs[("inject", s, 0.2, sd)] = (dict(scheme=s, attack="signflip", p_inject=0.2, seed=sd,
                                                 rounds=a.rounds), {}, crypto)
    # E6: DP-SGD privacy ledger (record-level DP)
    for sg in [1.0, 2.0]:
        for sd in list(seeds)[:3]:
            jobs[("dp", "AFL", sg, sd)] = (dict(scheme="AFL", attack="none", dp_sigma=sg, dp_budget=8.0,
                                               epochs=1, seed=sd, rounds=a.rounds), {}, crypto)

    keys = list(jobs)
    with ProcessPoolExecutor(a.workers) as ex:
        results = list(ex.map(_job, [jobs[k] for k in keys], chunksize=2))
    res = {"|".join(map(str, k)): r for k, r in zip(keys, results)}
    json.dump(res, open(os.path.join(OUT, "all_results.json"), "w"))
    print(f"done {len(keys)} runs in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
