"""Sanity tests: python -m pytest -q"""
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from afl.network import EdgeNetwork, NetConfig  # noqa: E402
from afl import optim, security  # noqa: E402
from afl.mcp import MCPServer, MCPClient, Tool, issue_token, MCPError  # noqa: E402
from afl.data import load_benchmark  # noqa: E402


def test_bandwidth_minmax_beats_equal():
    net = EdgeNetwork(NetConfig(seed=3))
    idx = np.where(net.edge_of == 0)[0][:5]
    tc = np.array([net.t_cmp(i, 80, 2) for i in idx])
    b, T = optim.minmax_bandwidth(net, idx, tc)
    assert b.sum() <= 1 + 1e-6
    t_eq = np.max(tc + net.t_up(idx, optim.equal_bandwidth(idx)))
    assert T <= t_eq + 1e-6


def test_mcp_roundtrip_and_scope():
    secret = b"k" * 32
    s = MCPServer("t", secret)
    s.add_tool(Tool("echo", "", {"type": "object", "properties": {"x": {"type": "integer", "maximum": 3}}},
                    lambda a: a, "a:write", lambda r: 0.0))
    c = MCPClient(s, issue_token(secret, "u", ["a:write"]), np.random.default_rng(0))
    out, lat = c.call_tool("echo", {"x": 2})
    assert out == {"x": 2} and lat > 0
    try:
        c.call_tool("echo", {"x": 9})
        assert False
    except MCPError as e:
        assert e.code == -32602
    c2 = MCPClient(s, issue_token(secret, "u", ["b:read"]), np.random.default_rng(0))
    try:
        c2.call_tool("echo", {"x": 1})
        assert False
    except MCPError as e:
        assert e.code == -32001


def test_rdp_monotone():
    e1 = security.epsilon(0.1, 1.0, 100)
    e2 = security.epsilon(0.1, 2.0, 100)
    assert e2 < e1


def test_data_partition():
    clients, (xte, yte), C, root = load_benchmark("ctg", 20, root_size=60)
    assert C == 3 and len(clients) == 20 and len(root[1]) == 60
    assert sum(len(c[1]) for c in clients) + len(yte) + 60 == 2126
